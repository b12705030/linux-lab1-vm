#!/bin/bash
echo "$(date): student (cron)" >> /home/student/logme_cron.txt
